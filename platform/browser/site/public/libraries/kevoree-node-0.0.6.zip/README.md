Kevoree Javascript Node
=======================
[Kevoree](http://kevoree.org) execution platform for Javascript