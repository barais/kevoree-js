var assert = require("assert");
var JSNode = require('../kevoree-node');

describe('Kevoree Javascript Node', function () {
    var node = new JSNode();

    // TODO
    describe('#startNode()', function () {
        it('todo', function () {
            // todo
        });
    });
});

